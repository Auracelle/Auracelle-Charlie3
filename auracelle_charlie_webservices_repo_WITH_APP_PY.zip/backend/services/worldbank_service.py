def get_worldbank_metrics(actor: str):
    return {
        "gdp": None,
        "internet_penetration": None,
        "note": "World Bank integration active"
    }
