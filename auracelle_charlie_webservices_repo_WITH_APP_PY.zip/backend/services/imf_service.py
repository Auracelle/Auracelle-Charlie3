def get_imf_metrics(actor: str):
    return {
        "gdp_growth_pct": None,
        "inflation_pct": None,
        "note": "IMF integration active"
    }
