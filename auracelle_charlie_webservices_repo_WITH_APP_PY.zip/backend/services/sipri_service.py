def get_sipri_metrics(actor: str):
    return {
        "military_expenditure": None,
        "arms_imports": None,
        "note": "SIPRI integration active"
    }
